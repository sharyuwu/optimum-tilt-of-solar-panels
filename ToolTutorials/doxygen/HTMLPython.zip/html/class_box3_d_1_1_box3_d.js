var class_box3_d_1_1_box3_d =
[
    [ "__init__", "class_box3_d_1_1_box3_d.html#a79295217172fd26315928d1be9e586f8", null ],
    [ "getAreaOfFace", "class_box3_d_1_1_box3_d.html#a4a1974f44cbb9b0b2c34e235115cc49a", null ],
    [ "getDimensions", "class_box3_d_1_1_box3_d.html#ae7efefdc171386d0c3f4405bc6029340", null ],
    [ "getDimensionsOfFace", "class_box3_d_1_1_box3_d.html#aa61fd686c15f3e4ac6710f1b15cfc661", null ],
    [ "getFrontTopLeftCorner", "class_box3_d_1_1_box3_d.html#aa767699637b029ffc93a0002cf283595", null ],
    [ "getPerimeterOfFace", "class_box3_d_1_1_box3_d.html#a14c479f7142c1a659ff2265973d68253", null ],
    [ "getSurfaceArea", "class_box3_d_1_1_box3_d.html#ae6fca86d5ee9022c80388c8e47814070", null ],
    [ "getVolume", "class_box3_d_1_1_box3_d.html#a53765b92e56a15380498871dff7a2396", null ],
    [ "setFrontTopLeftCorner", "class_box3_d_1_1_box3_d.html#a54bdfccf237602d3ec4f47c9aa87527f", null ],
    [ "__dimensions", "class_box3_d_1_1_box3_d.html#ad71e7e073d60722cf6792523722dda39", null ],
    [ "__frontTopLeftCorner", "class_box3_d_1_1_box3_d.html#a78f08dd76c3f69ded2d71a2883e9b660", null ],
    [ "b", "class_box3_d_1_1_box3_d.html#a95e3159914f9330093ac48062768a733", null ],
    [ "FRONT", "class_box3_d_1_1_box3_d.html#a60cb919c737a628e2c32d4181d9c7f33", null ],
    [ "SIDE", "class_box3_d_1_1_box3_d.html#a1a9d94c4359e7d7a6d177fe6bde663f5", null ],
    [ "TOP", "class_box3_d_1_1_box3_d.html#aff9713bf518710dd22a7be8a8223ea91", null ]
];