var files =
[
    [ "Box3D.py", "_box3_d_8py.html", [
      [ "Box3D", "class_box3_d_1_1_box3_d.html", "class_box3_d_1_1_box3_d" ]
    ] ]
];