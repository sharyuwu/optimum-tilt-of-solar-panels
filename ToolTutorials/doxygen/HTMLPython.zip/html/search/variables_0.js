var searchData=
[
  ['_5f_5fdimensions',['__dimensions',['../class_box3_d_1_1_box3_d.html#ad71e7e073d60722cf6792523722dda39',1,'Box3D::Box3D']]],
  ['_5f_5ffronttopleftcorner',['__frontTopLeftCorner',['../class_box3_d_1_1_box3_d.html#a78f08dd76c3f69ded2d71a2883e9b660',1,'Box3D::Box3D']]]
];
